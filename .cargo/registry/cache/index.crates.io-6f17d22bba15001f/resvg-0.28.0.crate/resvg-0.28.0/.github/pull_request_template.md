Pull requests that include:

- dependencies updates
- code formatting fixes
- clippy fixes
- compiler warnings fixes

will not be accepted.

The only exception are spellchecking and grammar fixes.

A pull request must contain a meaningful improvement to the project.
