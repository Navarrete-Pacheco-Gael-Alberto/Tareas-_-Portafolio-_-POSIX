## Usage

```sh
python gen-universal-table.py > ../src/complex/universal_table.rs

python3 ./gen-vowel-constraints.py > ../src/complex/vowel_constraints.rs
rustfmt ../src/complex/vowel_constraints.rs
```
