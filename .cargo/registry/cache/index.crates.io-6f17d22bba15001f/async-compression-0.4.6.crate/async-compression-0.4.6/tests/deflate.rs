#[macro_use]
mod utils;

test_cases!(deflate);
